#ifndef __SETJMP_DEF_H_
#define __SETJMP_DEF_H_

typedef unsigned long long __jmp_buf[32];

#endif // __SETJMP_DEF_H_
