#ifndef WINT_T_H_
#define WINT_T_H_

typedef unsigned wint_t;

#endif // WINT_T_H_
