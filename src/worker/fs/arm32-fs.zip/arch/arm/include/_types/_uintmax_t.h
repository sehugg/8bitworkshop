#ifndef __UINTMAX_T_H_
#define __UINTMAX_T_H_

typedef unsigned long long uintmax_t;

#endif //__UINTMAX_T_H_
