#ifndef WCHAR_T_H_
#define WCHAR_T_H_

#ifndef __cplusplus
typedef unsigned wchar_t;
#endif

#endif // WCHAR_T_H_
