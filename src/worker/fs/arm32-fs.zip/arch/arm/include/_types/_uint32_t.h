#ifndef __UINT32_T_H_
#define __UINT32_T_H_

typedef unsigned int uint32_t;

#endif //__UINT32_T_H_
