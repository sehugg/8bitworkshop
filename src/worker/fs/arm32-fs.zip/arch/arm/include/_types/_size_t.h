#ifndef __SIZE_T_H_
#define __SIZE_T_H_

typedef unsigned int size_t;

typedef int ssize_t;

#endif // __SIZE_T_H_
