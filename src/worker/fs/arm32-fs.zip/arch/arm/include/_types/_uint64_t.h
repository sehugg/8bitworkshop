#ifndef __UINT64_T_H_
#define __UINT64_T_H_

typedef unsigned long long uint64_t;

#endif //__UINT64_T_H_
