#ifndef __INT16_T_H_
#define __INT16_T_H_

typedef signed short int16_t;

#endif //__INT16_T_H_
