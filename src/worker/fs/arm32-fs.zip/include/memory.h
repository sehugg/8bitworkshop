#include <string.h>

/**
 * This file just serves as a functional passthrough to string.h.
 *
 * All primary definitions can be found in string.h. Please keep this file empty.
 */
